namespace WebMvc.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Mtendes",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        BookTitle = c.String(),
                        BookNumber = c.String(),
                        DateOfPublish = c.DateTime(nullable: false),
                        Author = c.String(),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Mtendes");
        }
    }
}
