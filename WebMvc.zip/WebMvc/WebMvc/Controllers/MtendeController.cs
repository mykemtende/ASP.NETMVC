﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebMvc.Models;

namespace WebMvc.Controllers
{
    public class MtendeController : Controller
    {
        private MtendeDBContext db = new MtendeDBContext();

        // GET: /Mtende/
        public ActionResult Index(string searchString)
        {
            var mtendes = from m in db.Mtende
                       select m; 

            if (!String.IsNullOrEmpty(searchString)) 
          {
              mtendes = mtendes.Where(s => s.BookTitle.Contains(searchString)); 
             } 
            //return View(db.Mtende.ToList());
            return View(mtendes);
        }




        // GET: /Mtende/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Mtende mtende = db.Mtende.Find(id);
            if (mtende == null)
            {
                return HttpNotFound();
            }
            return View(mtende);
        }

        // GET: /Mtende/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /Mtende/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="ID,BookTitle,BookNumber,DateOfPublish,Author,Price")] Mtende mtende)
        {
            if (ModelState.IsValid)
            {
                db.Mtende.Add(mtende);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(mtende);
        }

        // GET: /Mtende/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Mtende mtende = db.Mtende.Find(id);
            if (mtende == null)
            {
                return HttpNotFound();
            }
            return View(mtende);
        }

        // POST: /Mtende/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="ID,BookTitle,BookNumber,DateOfPublish,Author,Price")] Mtende mtende)
        {
            if (ModelState.IsValid)
            {
                db.Entry(mtende).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(mtende);
        }

        // GET: /Mtende/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Mtende mtende = db.Mtende.Find(id);
            if (mtende == null)
            {
                return HttpNotFound();
            }
            return View(mtende);
        }

        // POST: /Mtende/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Mtende mtende = db.Mtende.Find(id);
            db.Mtende.Remove(mtende);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
