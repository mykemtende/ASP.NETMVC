﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebMvc.Models
{
    public class Books
    {
        public int ID { get; set; }
        [Required, StringLength(60, MinimumLength = 3)]
        public string BookTitle { get; set; }
        [Required]
        public string BookNumber { get; set; }
         [Display(Name = "DateOfPublish"), DataType(DataType.Date)]
        public DateTime DateOfPublish { get; set; }
         [Required]
        public string Author { get; set; }
        [Range(1, 100000), DataType(DataType.Currency)]
       public decimal Price { get; set; }
}
      public class BooksDBContext : DbContext
{
          public DbSet<Books> Books { get; set; }
}
    }
