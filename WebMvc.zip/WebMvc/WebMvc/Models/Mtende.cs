﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace WebMvc.Models
{
    public class Mtende
    {
        public int ID { get; set; }
        public string BookTitle { get; set; }
        public string BookNumber { get; set; }
        public DateTime DateOfPublish { get; set; }
        public string Author { get; set; }
       public decimal Price { get; set; }
}
      public class MtendeDBContext : DbContext
{
          public DbSet<Mtende> Mtende { get; set; }
}
}